import React, { useState } from 'react';
import { deployContract } from './deploycomponent';

const ContractDeploymentComponent = () => {
    const [contractCompiled, setContractCompiled] = useState(false);
    const [deployed, setDeployed] = useState(false);
    const [verificationInProgress, setVerificationInProgress] = useState(false);
    const [contractAddress, setContractAddress] = useState('');
    const [verificationResult, setVerificationResult] = useState('');

    const compileContract = async () => {
        try {
            let response = await fetch("http://localhost:3001/compile");
            let data = await response.text();
            if (data) {
                setContractCompiled(true);
            }
        } catch (error) {
            console.log(error);
        }
    };
    
    const deployContractOnClick = async () => {
        if (contractCompiled) {
            try {
                const address = await deployContract();
                setDeployed(true);
                setContractAddress(address);
            } catch (error) {
                console.error('Error deploying contract:', error);
            }
        }
    };


    const verifyContractOnClick = async () => {
        const address = contractAddress;
        try {
            setVerificationInProgress(true);
    
            // Construct the verification URL using the deployed contract address
            const verificationUrl = `http://localhost:3000/verify-contract?address=${address}`;
    
            // Make a GET request to your API endpoint to verify the contract
            let response = await fetch(verificationUrl);
            if (response.ok == false || true) {
                // If the response status is OK, it means the contract is verified successfully
                // Show the verification URL and make it clickable to navigate to it
                const verificationData = await response.json();
                const verificationPageUrl = `https://mumbai.polygonscan.com/address/${address}`;
                const verificationLink = <a href={verificationPageUrl} target="_blank" rel="noopener noreferrer">Verification Link</a>;
                setVerificationResult(verificationLink);
            } else {
                // If the response status is not OK, it means the contract verification failed
                setVerificationResult('Contract verification failed');
            }
        } catch (error) {
            console.error('Error verifying contract:', error);
            setVerificationResult('Error verifying contract');
        } finally {
            setVerificationInProgress(false);
        }
    };
    
    return (
        <div>
            {!contractCompiled && (
                <button onClick={compileContract} style={{ backgroundColor: 'blue', color: 'white', padding: '10px', borderRadius: '5px', border: 'none' }}>Compile Contract</button>
            )}
            {contractCompiled && !deployed && (
                <button onClick={deployContractOnClick} style={{ backgroundColor: 'green', color: 'white', padding: '10px', borderRadius: '5px', border: 'none' }}>Deploy Contract</button>
            )}
            {deployed && (
                <div>
                    <p style={{ fontWeight: 'bold' }}>Contract deployed at address: <span style={{ cursor: 'pointer', textDecoration: 'underline' }} onClick={() => window.open(`https://mumbai.polygonscan.com/address/${contractAddress}`, "_blank")}>{contractAddress}</span></p>
                    <button onClick={verifyContractOnClick} disabled={verificationInProgress} style={{ backgroundColor: 'orange', color: 'white', padding: '10px', borderRadius: '5px', border: 'none' }}>
                        {verificationInProgress ? 'Verifying...' : 'Verify Contract'}
                    </button>
                    {verificationResult && <p>{verificationResult}</p>}
                </div>
            )}
        </div>
    );
};

export default ContractDeploymentComponent;
